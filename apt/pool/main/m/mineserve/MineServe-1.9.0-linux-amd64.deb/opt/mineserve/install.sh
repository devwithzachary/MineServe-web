#!/usr/bin/env bash
set -e
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ "$(id -u)" -eq 0 ]; then
    echo "Installing MineServe system-wide to /opt/mineserve..."
    rm -rf /opt/mineserve
    mkdir -p /opt/mineserve
    cp -a "$SRC_DIR"/* /opt/mineserve/
    ln -sf /opt/mineserve/bin/mineserve /usr/bin/mineserve
    chmod 755 /opt/mineserve/bin/mineserve 2>/dev/null || true
    install -Dm644 "$SRC_DIR/share/mineserve.desktop" /usr/share/applications/mineserve.desktop
    install -Dm644 "$SRC_DIR/share/mineserve.png" /usr/share/icons/hicolor/512x512/apps/mineserve.png
    install -Dm644 "$SRC_DIR/share/mineserve.png" /usr/share/pixmaps/mineserve.png
    install -Dm644 "$SRC_DIR/share/mineserve.service" /lib/systemd/system/mineserve.service
    install -Dm644 "$SRC_DIR/share/mineserve.sysusers" /usr/lib/sysusers.d/mineserve.conf
    systemd-sysusers /usr/lib/sysusers.d/mineserve.conf 2>/dev/null || true
    echo "Installed! Launch 'mineserve' from your application menu or terminal, or run 'mineserve --headless'."
else
    echo "Installing MineServe for current user to ~/.local/opt/mineserve..."
    rm -rf "$HOME/.local/opt/mineserve"
    mkdir -p "$HOME/.local/opt/mineserve" "$HOME/.local/bin" "$HOME/.local/share/applications" "$HOME/.local/share/icons/hicolor/512x512/apps"
    cp -a "$SRC_DIR"/* "$HOME/.local/opt/mineserve/"
    chmod 755 "$HOME/.local/opt/mineserve/bin/mineserve" 2>/dev/null || true
    ln -sf "$HOME/.local/opt/mineserve/bin/mineserve" "$HOME/.local/bin/mineserve"
    sed "s|Exec=/usr/bin/mineserve|Exec=$HOME/.local/bin/mineserve|g" "$SRC_DIR/share/mineserve.desktop" > "$HOME/.local/share/applications/mineserve.desktop"
    cp "$SRC_DIR/share/mineserve.png" "$HOME/.local/share/icons/hicolor/512x512/apps/mineserve.png"
    echo "Installed! Launch MineServe from your application launcher or run '$HOME/.local/bin/mineserve'."
fi
